from pyspark.sql import SparkSession
from pyspark.sql.types import StructType, StructField, IntegerType, StringType
from pyspark.sql import Row
from pyspark.sql.functions import max as spark_max
from delta.tables import DeltaTable
import os

# -------------------
# Spark session
# -------------------
spark = (
    SparkSession.builder
        .appName("Delta S3 Hive Auto Insert")
        .master("local[*]")
        .config("spark.jars.packages",
                "io.delta:delta-spark_2.13:4.0.0,org.apache.hadoop:hadoop-aws:3.4.1")
        .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
        .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
        # MinIO / S3
        .config("spark.hadoop.fs.s3a.endpoint", "http://minio:9000")
        .config("spark.hadoop.fs.s3a.access.key", "admin")
        .config("spark.hadoop.fs.s3a.secret.key", "password")
        .config("spark.hadoop.fs.s3a.path.style.access", "true")
        .config("spark.hadoop.fs.s3a.connection.ssl.enabled", "false")
        .config("spark.sql.warehouse.dir", "s3a://warehouse/")
        # Hive Metastore
        .config("spark.hadoop.hive.metastore.uris", "thrift://hive-metastore:9083")
        .config("spark.sql.catalogImplementation", "hive")
        .getOrCreate()
)

print("Spark session started")

# -------------------
# Define schema
# -------------------
schema = StructType([
    StructField("id", IntegerType(), True),
    StructField("name", StringType(), True)
])

# -------------------
# Create Hive database if missing
# -------------------
spark.sql("CREATE DATABASE IF NOT EXISTS test_db")

# -------------------
# Delta table path
# -------------------
table_name = "test_db.test_delta_table"
table_path = "s3a://warehouse/test_db.db/test_delta_table"

# -------------------
# Create Delta table if missing
# -------------------
if not DeltaTable.isDeltaTable(spark, table_path):
    print("Delta table does not exist, creating with sample data...")
    data = [(1, "Alice"), (2, "Bob")]
    df = spark.createDataFrame(data, schema)
    df.write.format("delta").mode("overwrite").option("overwriteSchema", "true").saveAsTable(table_name)
else:
    print("Delta table exists, appending new row...")

# -------------------
# Load existing Delta table
# -------------------
delta_table = DeltaTable.forName(spark, table_name)
existing_df = delta_table.toDF()

# -------------------
# Generate new ID
# -------------------
max_id = existing_df.agg(spark_max("id")).collect()[0][0] or 0
new_id = max_id + 1

# -------------------
# Create new row
# -------------------
new_row = [Row(id=new_id, name=f"User_{new_id}")]
df_new = spark.createDataFrame(new_row, schema=schema)

# -------------------
# Append new row
# -------------------
df_new.write.format("delta").mode("append").saveAsTable(table_name)

# -------------------
# Verify
# -------------------
spark.table(table_name).show()