from pyspark.sql import SparkSession
from delta import *

spark = SparkSession.builder \
    .appName("Delta Test") \
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension") \
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog") \
    .getOrCreate()

print("Spark session started with Delta")

# Example DataFrame
data = [("Alice", 1), ("Bob", 2)]
df = spark.createDataFrame(data, ["name", "id"])

df.show()

spark.stop()