from pyspark.sql import SparkSession
from pyspark.sql.functions import lit
from py4j.java_gateway import java_import

ingest_root = "s3a://warehouse/fs/ecg_raw"
target_table = "hyb_bronze.ecg_test"
checkpoint_path = "s3a://warehouse/fs/checkpoints"

spark = (
    SparkSession.builder
    .appName("Delta ECG Job")
    .master("local[*]")
    .config("spark.jars.packages", "io.delta:delta-spark_2.13:4.0.0,org.apache.hadoop:hadoop-aws:3.4.1")
    .config("spark.sql.extensions", "io.delta.sql.DeltaSparkSessionExtension")
    .config("spark.sql.catalog.spark_catalog", "org.apache.spark.sql.delta.catalog.DeltaCatalog")
    .config("spark.hadoop.fs.s3a.endpoint", "http://minio:9000")
    .config("spark.hadoop.fs.s3a.access.key", "admin")
    .config("spark.hadoop.fs.s3a.secret.key", "password")
    .config("spark.hadoop.fs.s3a.path.style.access", "true")
    .config("spark.hadoop.fs.s3a.connection.ssl.enabled", "false")
    .config("spark.sql.warehouse.dir", "s3a://warehouse/")
    .getOrCreate()
)

# Read all files from S3
df = spark.read.parquet(ingest_root)
df.write.format("delta").mode("append").option("mergeSchema", "true").saveAsTable(target_table)