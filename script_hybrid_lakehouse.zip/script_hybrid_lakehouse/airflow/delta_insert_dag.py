from airflow import DAG
from airflow.operators.bash import BashOperator
from datetime import datetime, timedelta

default_args = {
    'owner': 'airflow',
    'depends_on_past': False,
    'email_on_failure': False,
    'email_on_retry': False,
    'retries': 1,
    'retry_delay': timedelta(minutes=1),
}

dag = DAG(
    'delta_s3_hive_insert',
    default_args=default_args,
    description='Append new row to Delta table in S3 via Hive',
    schedule_interval='@daily',  # or adjust to your need
    start_date=datetime(2025, 12, 21),
    catchup=False,
)

# -------------------
# BashOperator to run your spark-submit script
# -------------------
spark_submit_cmd = """
docker exec delta-spark \
spark-submit \
--master local[*] \
--packages io.delta:delta-spark_2.13:4.0.0,org.apache.hadoop:hadoop-aws:3.4.1 \
/opt/create_delta_table.py
"""


run_spark = BashOperator(
    task_id='run_delta_spark',
    bash_command=spark_submit_cmd,
    dag=dag
)

run_spark